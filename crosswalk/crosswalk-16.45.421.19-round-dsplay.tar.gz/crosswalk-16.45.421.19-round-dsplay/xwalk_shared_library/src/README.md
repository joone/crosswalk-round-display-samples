# Source folder for xwalk library
## Why it's empty
xwalk library doesn't contain java sources.
## Why put me here
To make archives keep the folder, the src directory is needed to build an apk by ant.